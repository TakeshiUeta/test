package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.from.Enemy;
import com.example.from.User;
import com.example.from.UserForm;

@Controller
public class TestController {
	@GetMapping("/test")
	public String getTest(Model model) {
		List <User> usersList = new ArrayList<>();
		int enemyId = 1;
		String enemyName = "キング";
		int hp = 500;
		Enemy enemy = new Enemy(enemyId,enemyName,hp);
		String nameOrigin="上田";
		for(int i = 0;i < 3; i++) {
			String value = Integer.toString(i + 1);
			String name = nameOrigin + value; 
			String id=Integer.toString(i + 1);;
			int age=i+46;
			User user = new User(id,name,age);
			usersList.add(user);
		}
		model.addAttribute("usersList",usersList);
		model.addAttribute("enemy",enemy);
		return "test";
	}
	@PostMapping("/test/update")
	public String updateCharacter(@ModelAttribute UserForm form) {
	    System.out.println("受け取った名前: " + form.getUsersList().get(0).getCharacter().getName());
	    System.out.println("受け取ったHP: " + form.getUsersList().get(0).getCharacter().getHp());
	    System.out.println("受け取ったMP: " + form.getUsersList().get(0).getCharacter().getMp());
	    return "redirect:/test";
	}
}
