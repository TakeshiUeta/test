package com.example.from;


import lombok.Data;

@Data
public class User {
	String id;
	String name;
	int age;
	PlayerCharacter character;
	User(){}
	public User(String id,String name,int age){
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public User(String id,String name,int age,PlayerCharacter character){
		this.id = id;
		this.name = name;
		this.age = age;
		this.character =character;
	}
}
