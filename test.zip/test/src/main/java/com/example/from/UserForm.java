package com.example.from;

import lombok.Data;
import java.util.List;

@Data
public class UserForm {
    private List<User> usersList;
}
