package com.example.from;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

import lombok.Data;

@Data
public class Enemy {
	int id;
	String name;
	int hp;
	public Enemy() {}
	public Enemy(int id,String name,int hp) {
		this.id = id;
		this.name = name;
		this.hp = hp;
	}
}
