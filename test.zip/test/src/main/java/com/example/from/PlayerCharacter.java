package com.example.from;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class PlayerCharacter {
	int id;
	String name;
	int hp;
	int mp;
	/**コンストラクタ*/
	public PlayerCharacter() {}
	public PlayerCharacter(
			int id,
			String name,
			int hp,
			int mp
			) {
		this.id=id;
		this.name=name;
		this.hp=hp;
		this.mp=mp;
	}
}
